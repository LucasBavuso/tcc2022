<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="princss.css">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>

<body style="margin: 0;">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>

    <div style="background-color: #1c110a; height: 120px; margin: 0;">
        <a href="index.php"><img src="imagens/logore.png" alt="logo"
                style="width:220px; height:220px; position: absolute; top: -57px; left: -30px;position: fixed;">
        </a>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="background-color: #e9b44c;">
            <h3 style="text-align: center; color:#9B2915">INSIRA SEUS DADOS</h3>
        </div>
        <div class="posi" style=" right: 140px; ">
            <a href="logar.php">
                <button
                    style="height: 45px; background-color: #e9b44c;position: fixed; border-radius: 10px; top:38.2px">ENTRAR</button>
            </a>
        </div>
        <nav class="navbar navbar-expand-lg rounded"
            style="background-color: #e9b44c; position:absolute ;right: 150px; top:40px; ">
            <a class="nav-link dropdown-toggle px-2 " href="#" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                CADASTRAR
            </a>
            <ul class="dropdown-menu" style="background-color: #facd74">
                <li><a class="dropdown-item" href="cadastro.php">Cadastrar cliente</a></li>
                <li><a class="dropdown-item" href="cadastromicro.php">Cadastrar Empreendedor</a></li>
                <li>
            </ul>
            </li>
        </nav>
    </div>
    <div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <form action="login.php" method="post">
            <fieldset style="background-color: #E4D6A7; height: 350px;width: 750px; border-color: #1C110A; position:absolute; top:35%;right:600px;border:solid; border-radius:10px"
                class="container">
                <label for="txtTitulo" style="font-size: 40px;">Entrar</label>
                <br>
                <br>
                <br>
                <input type="text" name="txtEmail" style="width: 99%; height: 40px; border-radius:5px" autofocus placeholder="E-mail"
                    required />
                <br>
                <br>
                <input type="text" name="txtSenha" style="width: 99%; height: 40px; border-radius:5px" autofocus placeholder="Senha"
                    required />
                <br>
                <br>
                <button onclick="" style="right: 2.6%; top: 70%;  border-radius:5px" class="buttonc">Entrar</button>
                <button onclick="" style="left: 1.9%; top: 70%; border-radius:5px" class="buttonc">Cancelar</button>
            </fieldset>
        </form>
        <br>
        <br>
        <br>
        <br>
    </div>
</body>

</html>