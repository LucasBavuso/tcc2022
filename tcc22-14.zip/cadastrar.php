<?php
include 'conexao.php';
$nome = $_POST["txtNome"];
$email = $_POST["txtEmail"];
$senha = $_POST["txtSenha"];
$data = $_POST["dateNasci"];
$sql = "INSERT INTO tbCliente (nomeCompleto, email, senha, dataNascimento)
VALUES ('".$nome."', '".$email."','".$senha."','".$data."')";
echo $sql;

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Registro inserido com sucesso.');</script>";
    echo "<script>window.location = 'princlog.php';</script>";
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
    //echo "<script>window.history.back();</script>";
}
$conn->close();
?>

