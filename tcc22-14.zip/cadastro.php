<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="princss.css">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>

<body style="margin: 0;">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>
    <div style="background-color: #1c110a; height: 120px; margin: 0;">
        <a href="index.php"><img src="imagens/logore.png" alt="logo"
                style="width:220px; height:220px; position: absolute; top: -57px; left: -30px;position: fixed;">
        </a>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="background-color: #e9b44c;">
            <h3 style="text-align: center; color:#9B2915">INSIRA SEUS DADOS</h3>
            <div class="posi" style=" right: 140px; ">
                <a href="logar.php">
                    <button
                        style="height: 45px; background-color: #e9b44c;position: fixed; border-radius: 10px; top:38.2px">ENTRAR</button>
                </a>
            </div>
            <nav class="navbar navbar-expand-lg rounded"
                style="background-color: #e9b44c; position:absolute ;right: 150px; top:40px; ">
                <a class="nav-link dropdown-toggle px-2 " href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    CADASTRAR
                </a>
                <ul class="dropdown-menu" style="background-color: #facd74">
                    <li><a class="dropdown-item" href="cadastro.php">Cadastrar cliente</a></li>
                    <li><a class="dropdown-item" href="cadastromicro.php">Cadastrar Empreendedor</a></li>
                    <li>
                </ul>
                </li>
        </div>
    </div>
    </nav>
    </div>
    </div>
    <div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <script>
        function verificaCampos() {
            document.getElementById("nome").setAttribute("required", "");
            document.getElementById("email").setAttribute("required", "");
            document.getElementById("senha").setAttribute("required", "");
            document.getElementById("data").setAttribute("required", "");
        }
        </script>




        <form action="cadastrar.php" method="post">
            <fieldset style="background-color: #E4D6A7; height: 470px; width:50%; width: 800px;border-color: #1C110A;
             position:absolute; right: 29%; top: 30%; border-radius:10px;border:solid" class="container">
                <label for="txtTitulo" style="font-size: 40px;">Cadastrar</label>
                <br>
                <br>

                <input type="text" name="txtNome" style="width: 100%; height: 40px; border-radius:5px" autofocus
                    placeholder="Nome Completo" id="nome" />
                <br>
                <br>
                <input type="text" name="txtEmail" style="width: 100%; height: 40px; border-radius:5px" autofocus
                    placeholder="E-mail" id="email" />
                <br>
                <br>
                <input type="text" name="txtSenha" style="width: 100%; height: 40px; border-radius:5px" autofocus
                    placeholder="Senha" id="senha" />
                <br>
                <br>
                <label for="data"> Data de nacimento: </label>
                <input type="date" name="dateNasci" id="" style="width: 81.4%; height: 40px; border-radius:5px"
                    id="data">
                <br>
                <br>
                <br>
                <button onclick="verificaCampos()" style="right: 2%; top: 70p; border-radius:5px;"
                    class="buttonc">Cadastrar</button>

                <input type="reset" class="buttonc" style="float: left; border-radius:5px" value="Cancelar">
                <br>
                <br>
                <br>



            </fieldset>
        </form>

        <br>
        <br>
        <br>
        <br>
    </div>
</body>

</html>